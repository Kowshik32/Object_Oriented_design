public class Calculation extends Variable{
    void viewtolllist()
    {
        System.out.println("1.Motorcycle           :100  Tk");
        System.out.println("2.Car/Jeep             :750  Tk");
        System.out.println("3.Pickup               :1200 Tk");
        System.out.println(" 4.Microbus            :1300");
        System.out.println("5.Minibus              :1400 Tk");
        System.out.println("6.Medium bus           :2000 TK");
        System.out.println("7.Big bus              :2400TK");
        System.out.println("8.Truck(upto 5 tonnes) :1600 Tk");
        System.out.println("9.Truck (5-8 tonnes)   :2100 Tk");
        System.out.println("10.Truck (3 axle)      :5500 Tk");
        System.out.println("11.Trailer(4 axle)     :6000 Tk");
    }
    void calculate()
    {
        System.out.println("@------- Welcome to padma bridge tooling System--------@");
        System.out.println("0.Day Report");
        System.out.println("1.Motorcycle");
        System.out.println("2.Car/Jeep");
        System.out.println("3.Pickup");
        System.out.println("4.Microbus");
        System.out.println("5.Minibus");
        System.out.println("6.Medium bus");
        System.out.println("7.Big bus");
        System.out.println("8.Truck(upto 5 tonnes)");
        System.out.println("9.Truck (5-8 tonnes)");
        System.out.println("10.Truck (3 axle)");
        System.out.println("11.Trailer(4 axle)");
    }
}
